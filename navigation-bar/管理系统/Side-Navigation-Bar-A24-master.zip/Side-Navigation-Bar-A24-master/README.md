# Side-Navigation-Bar-A24
How to create the Side Navigation Bar Using HTML CSS and Javascript 
